<?php

require_once "../php/userdata.php";

if (isset($_SESSION["loggedIN"])) {
    $loggedIN = $_SESSION["loggedIN"];
}

if ($loggedIN == false) {
    header("Location: /");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App | <?php echo TITLE; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="./css/main.css">
    <script src="https://kit.fontawesome.com/73d4b4352e.js" crossorigin="anonymous"></script>
</head>

<style>
    #sideNav {
        transition: all 0.5s;
        -webkit-transition: all 0.25s;
        z-index: 100;
    }

    .text-hr {
        margin-left: 15px !important;
        margin-top: 10px !important;
        margin-bottom: -6px !important;
    }

    .sidenav {
        transition: all 0.1s;
        -webkit-transition: all 0.1s;
    }

    .sidenav::after {
        margin-left: 300px;
    }

    .sidenav-button {
        transition: all 0.5s;
        -webkit-transition: all 0.25s;
    }

    .sidenav-button:hover {
        transform: translate(0px, 5px);
    }

    .sideNavbackground {
        z-index: 10;
        width: 200%;
        height: 100vh;
        background-color: #212121;
        position: fixed;
        opacity: 0.6;
        transition: all 0.25s;
        -webkit-transition: all 0.25;
    }

    .add-note-UI {
        z-index: 1000000;
        width: 100%;
        height: 100vh;
        position: fixed;
        transition: all 0.5s;
        -webkit-transition: all 0.2s;
    }

    .card-body-index {
        display: inline-block;
        margin-bottom: 15px !important;
        width: 100% !important;
        margin-top: 100%;
        -webkit-user-select: none;
        /* Safari */
        -ms-user-select: none;
        /* IE 10 and IE 11 */
        user-select: none;
        /* Standard syntax */
    }

    .created-in {
        -webkit-user-select: none;
        /* Safari */
        -ms-user-select: none;
        /* IE 10 and IE 11 */
        user-select: none;
        /* Standard syntax */
    }

    .card-body-index-body {
        position: absolute;
        left: 50%;
        top: 50%;
        width: 100% !important;
        padding: 5rem;
        transform: translate(-50%, -50%);
    }

    #card-body-index-body{
        width: 100% !important;
        height: 100vh !important;
        word-break: break-all;
    }

    .card-body-index-body-child_2{
        transform: translate(-50%, -50%);
    }

    .add-note-button {
        border-radius: 64px;
    }

    #note_id {
        color: #9ca3af;
        background-color: #374151;
        cursor: default;
        pointer-events: none;
        -webkit-user-select: none;
        /* Safari */
        -ms-user-select: none;
        /* IE 10 and IE 11 */
        user-select: none;
        /* Standard syntax */
    }

    .card-body-index-body-child {
        word-break: break-all;
        overflow-y: hidden;
        text-overflow: clip;
        white-space: nowrap;
    }

    button[type="submit"]:disabled {
        color: #9ca3af;
        background-color: #374151;
        cursor: default;
        pointer-events: none;
        -webkit-user-select: none;
        /* Safari */
        -ms-user-select: none;
        /* IE 10 and IE 11 */
        user-select: none;
        /* Standard syntax */
    }

    input[type="text"]:disabled {
        border-color: #475569;
        background-color: #374151;
        -webkit-user-select: none;
        /* Safari */
        -ms-user-select: none;
        /* IE 10 and IE 11 */
        user-select: none;
        /* Standard syntax */
    }

    input[type="text"]:disabled::placeholder {
        color: #6b7280;
        -webkit-user-select: none;
        /* Safari */
        -ms-user-select: none;
        /* IE 10 and IE 11 */
        user-select: none;
        /* Standard syntax */
    }

    /* cursor-pointer hover:dark:bg-slate-600 transition ease-in duration-300 */
</style>

<body class="dark:bg-slate-800 font-[Poppins]">
    <span id="openSideNav" class="sidenav-button absolute text-white text-4xl top-5 left-5 cursor-pointer z-01">
        <i class="bi bi-list"></i>
    </span>
    <div id="sideNav" class=" fixed left-[-350px] sidenav z-50 fixed top-0 bottom-0 duration-2000
    p-2 w-[300px] overflow-y-auto text-center dark:bg-slate-700 h-screen">
        <div class="text-gray-100 text-xl">
            <div class="p-2.5 mt-1 flex items-center rounded-md" id="closeSideNav">
                <i class="bi bi-x ml-auto cursor-pointer"></i>
            </div>
            <div>
                <div class="text-hr">
                    <p class="text-slate-400 text-sm text-left right-10">
                        General
                    </p>
                </div>
                <a href="./dashboard">
                    <div class="button p-2.5 mt-2 flex items-center rounded-r-full px-4 rounded-r-full duration-200 cursor-pointer hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-house"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Home</span>
                    </div>
                </a>
                <a href="./notes">
                    <div class="button p-2.5 bg-slate-600 mt-2 flex items-center px-4 duration-200 cursor-pointer rounded-r-full hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-book"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Notes</span>
                    </div>
                </a>
                <div class="text-hr">
                    <p class="text-slate-400 text-sm text-left right-10">
                        Add
                    </p>
                </div>
                <div class="button p-2.5 mt-2 flex items-center px-4 duration-200 cursor-pointer rounded-r-full hover:rounded-r-full hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                    <i class="fa-solid fa-file"></i>
                    <span class="text-[15px] ml-4 text-gray-200">Add File</span>
                </div>
                <div class="button p-2.5 mt-2 flex items-center px-4 duration-200 cursor-pointer rounded-r-full hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                    <i class="fa-solid fa-folder"></i>
                    <span class="text-[15px] ml-4 text-gray-200">Add Folder</span>
                </div>
                <div class="text-hr">
                    <p class="text-slate-400 text-sm text-left right-10">
                        Manage Account
                    </p>
                </div>
                <a href="/settings">
                    <div class="button p-2.5 mt-2 flex items-center rounded-sm px-4 rounded-r-full duration-200 cursor-pointer hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-gear"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Settings</span>
                    </div>
                </a>
                <a href="php/logout">
                    <div class="button p-2.5 mt-2 flex items-center rounded-r-full px-4 rounded-r-full duration-200 cursor-pointer hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Logout</span>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="sideNavbackground top-[-9000px]" id="sideNavbackground"></div>
    <div class=" top-[-5000px] dark:bg-slate-700 add-note-UI duration-300 flex items-center justify-center min-h-screen" id="add-note-UI">
        <span id="closeNoteUI" class="absolute text-white text-4xl top-5 left-5 cursor-pointer z-50">
            <i class="fa-solid fa-xmark duration-300 transition ease-in hover:text-gray-400"></i>
        </span>
        <div class="w-full bg-white max-w-sm rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-slate-800 dark:border-slate-600">
            <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
                <div class="justify-center">
                    <h1 class="uppercase text-4xl font-bold leading-tight tracking-tight text-slate-900 md:text-2xl dark:text-white">
                        Create note
                    </h1>
                </div>
                <form class="space-y-4 md:space-y-6" action="" id="noteform" method="POST">
                    <div>
                        <input type="text" name="note_text" id="note_text" placeholder="Text" class=" transition ease-in outline-0 dark:bg-slate-700 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-slate-700 dark:border-slate-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    </div>
                    <button type="submit" id="createnote" name="createnote" class="cursor-pointer w-full text-white transition ease-in hover:dark:bg-slate-600 dark:bg-slate-700 hover:bg-slate-700 focus:ring-4 focus:outline-none focus:ring-slate-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-slate-600 dark:hover:bg-slate-700 dark:focus:ring-slate-800">Create</button>
                </form>
            </div>
        </div>
    </div>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js"></script>


    <div id="card-body-index-body" class="p-10 container flex justify-center mt-auto mx-auto">
        <div class="p-auto p-10 w-full max-w-sm mt-auto mx-auto dark:text-slate-300 justify-center w-full rounded dark:bg-slate-700 shadow-lg text-center">
            <?php
            $sql = "SELECT * FROM notes";
            $res = mysqli_query($conn, $sql);
            if (mysqli_num_rows($res) > 0) {
                while ($rows = mysqli_fetch_assoc($res)) {

            ?>
                    <div id="openNoteUI_<?= $rows["id"] ?>" class="p-4 mr-3 ml-3 px-3 dark:text-slate-400 text-white text-lg dark:bg-slate-800 w-full rounded inline-block max-w-sm mt-2 hover:dark:bg-slate-600 cursor-pointer shadow-lg transition ease-in duration-300">
                        <?= $rows["text"] ?>
                    </div>
                    <script>
                        $(document).ready(function() {
                            $("#openNoteUI_<?= $rows["id"] ?>").on("click", function() {
                                $("#note-UI_<?= $rows["id"] ?>").addClass("-top-[-0px]")
                                $("#sideNavbackground").removeClass("-top-[-0px]")
                                $("#sideNav").removeClass("-left-[-0px]");
                            });
                            $("#closeNoteUI_<?= $rows["id"] ?>").on("click", function() {
                                $("#note-UI_<?= $rows["id"] ?>").removeClass("-top-[-0px]")
                                $("#openSideNav").css("opacity", "1")
                            });
                        });
                    </script>
                <?php
                }
            } else {
                ?>
                <div class="p-4 mr-3 ml-3 px-3 dark:text-slate-400 text-white text-lg w-full rounded inline-block max-w-sm mt-2">
                    Create one to see here.
                </div>
            <?php } ?>
        </div>
    </div>
    <?php
    $sql = "SELECT * FROM notes";
    $res = mysqli_query($conn, $sql);
    if (mysqli_num_rows($res) > 0) {
        while ($rows = mysqli_fetch_assoc($res)) {

    ?>
            <div class=" top-[-5000px] dark:bg-slate-700 add-note-UI duration-300" id="note-UI_<?= $rows["id"] ?>">
                <span id="closeNoteUI_<?= $rows["id"] ?>" class="absolute text-white duration-300 transition ease-in text-gray text-4xl top-5 left-5 cursor-pointer z-50">
                    <i class="fa-solid fa-xmark"></i>
                </span>

                <span id="notetimeCreated" class="uppercase created-in dark:text-slate-500 absolute text-white text-lg bottom-5 left-5 z-50">
                    <?php echo "Created " . timeExchange($rows["time_created"]) . ""; ?>
                </span>
                <span id="notetimeCreated" class="uppercase created-in dark:text-slate-500 absolute text-white text-2xl top-5 right-5 z-50">
                    Details
                </span>
                <span id="deleteNote_button_<?= $rows["id"] ?>" class="created-in dark:text-slate-500 cursor-pointer transition ease-in hover:dark:text-slate-600 duration-400 absolute text-white text-2xl bottom-5 right-5 z-50">
                    <i class="fa-solid fa-trash-can"></i>
                </span>
            </div>

            <div class=" top-[-5000px] dark:bg-slate-700 add-note-UI duration-300" id="deleteNote-UI_<?= $rows["id"] ?>">
                <span id="deletecloseNoteUI_<?= $rows["id"] ?>" class="absolute text-white duration-300 transition ease-in text-gray text-4xl top-5 left-5 cursor-pointer z-50">
                    <i class="fa-solid fa-xmark"></i>
                </span>

                <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto h-screen lg:py-0">
                    <div class="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                        <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
                            <div class="justify-center">
                                <h1 class="uppercase text-4xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                                    DELETE NOTE
                                </h1>
                            </div>
                            <form class="space-y-4 md:space-y-6" action="" id="deletenoteform" method="POST">
                                <div>
                                    <input style="color: #9ca3af; background-color: #374151; cursor: default; pointer-events: none;" value="<?= $rows["id"] ?>" type="text" name="note_id" id="note_id_<?= $rows["id"] ?>" placeholder="Note ID" class="transition ease-in outline-0 bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                                <button type="submit" id="deletenote_<?= $rows["id"] ?>" name="deletenote" class="cursor-pointer w-full text-white transition ease-in hover:dark:bg-gray-600 dark:bg-gray-700 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>

                <span id="notetimeCreated" class="uppercase created-in dark:text-slate-500 absolute text-white text-2xl top-5 right-5 z-50">
                    Delete Id. <?= $rows["id"] ?>
                </span>
            </div>
            <script>
                $(document).ready(function() {
                    $("#deleteNote_button_<?= $rows["id"] ?>").on("click", function() {
                        $("#deleteNote-UI_<?= $rows["id"] ?>").addClass("-top-[-0px]")
                        $("#sideNavbackground, #note-UI_<?= $rows["id"] ?>").removeClass("-top-[-0px]")
                        $("#sideNav").removeClass("-left-[-0px]");
                    });
                    $("#deletecloseNoteUI_<?= $rows["id"] ?>").on("click", function() {
                        $("#deleteNote-UI_<?= $rows["id"] ?>").removeClass("-top-[-0px]")
                        $("#openSideNav").css("opacity", "1")
                    });
                });
            </script>
            <script>
                $(document).ready(function() {
                    $("#deletenoteform").submit(function(e) {
                        e.preventDefault();

                        var note_id = $("#note_id_<?= $rows["id"] ?>").val()
                        var submit = $("#deletenote_<?= $rows["id"] ?>").val()

                        $.ajax({
                            url: "php/delete.php",
                            dataType: "text",
                            data: {
                                deletenote: 1,
                                note_id: note_id
                            },
                            type: "POST",
                            success: function(response) {
                                console.log(response)
                                if (response === "Successfuly deleted the note.") {
                                    $("#deletenote_<?= $rows["id"] ?>").prop("disabled", true);
                                    $("#deletenote_<?= $rows["id"] ?>").html("Deleting note...")
                                    setTimeout(function() {
                                        $("#deleteNote-UI_<?= $rows["id"] ?>").removeClass("-top-[-0px]")
                                    }, 1000)
                                    setTimeout(function() {
                                        location.href = window.location.href
                                    }, 4000)
                                    setTimeout(function() {
                                        Swal.fire({
                                            icon: "success",
                                            text: `${response}`
                                        })
                                    }, 2000)
                                }
                            },
                            error: function() {}
                        })
                    })
                })
            </script>
    <?php }
    } ?>

    <span id="openNoteUI" class="absolute text-white text-4xl bottom-5 right-5 cursor-pointer z-10">
        <i class="fa-solid fa-plus add-note-button text-white text-xl shadow-lg dark:bg-slate-700 hover:dark:bg-slate-600 px-3 py-2 duration-300 transition ease-in"></i>
    </span>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js"></script>
    <script>
        // function dropDown() {
        //     document.querySelector('#submenu').classList.toggle('hidden')
        //     document.querySelector('#arrow').classList.toggle('rotate-0')
        // }
        // dropDown()

        $(document).ready(function() {
            $("#noteform").submit(function(e) {
                e.preventDefault();

                var addnoteUI = $("#add-note-UI").val()
                var notetext = $("#note_text").val()
                var submit = $("#createnote").val()

                if (!notetext) {
                    Swal.fire({
                        icon: "error",
                        text: "Note is empty!"
                    })
                    $("#add-note-UI").removeClass("-top-[-0px]")
                }

                $.ajax({
                    url: "php/create.php",
                    dataType: "text",
                    data: {
                        createnote: 1,
                        note_text: notetext
                    },
                    type: "POST",
                    success: function(response) {
                        console.log(response)
                        if (response === "Successfully created note.") {
                            $("#createnote").prop("disabled", true);
                            $("#note_text").prop("disabled", true);
                            $("#createnote").html("Creating note...");
                            setTimeout(function() {
                                $("#add-note-UI").removeClass("-top-[-0px]")
                            }, 1000)
                            setTimeout(function() {
                                location.href = window.location.href
                            }, 4000)
                            setTimeout(function() {
                                Swal.fire({
                                    icon: "success",
                                    text: `${response}`
                                })
                            }, 2000)
                        }
                    },
                    error: function() {}
                })
            })
        })

        $("#copyTextNote").on("click", function() {
            navigator.clipboard.writeText(this.value)

            Swal.fire({
                icon: "success",
                text: "Text copied!"
            })
        })

        $(document).ready(function() {
            $("#openSideNav").on("click", function() {
                $("#sideNavbackground").addClass("-top-[-0px]")
                $("#openSideNav").css("opacity", "0");
                $("#sideNav").addClass("-left-[-0px]");
            });
            $("#closeSideNav").on("click", function() {
                $("#sideNavbackground").removeClass("-top-[-0px]")
                $("#sideNav").removeClass("-left-[-0px]");
                $("#openSideNav").css("opacity", "1");
            });
            $("#sideNavbackground").on("click", function() {
                $("#sideNavbackground").removeClass("-top-[-0px]")
                $("#sideNav").removeClass("-left-[-0px]")
                $("#openSideNav").css("opacity", "1");
            })
        });

        $(document).ready(function() {
            $("#openNoteUI").on("click", function() {
                $("#add-note-UI").addClass("-top-[-0px]")
                $("#sideNavbackground").removeClass("-top-[-0px]")
                $("#sideNav").removeClass("-left-[-0px]");
                $("#openSideNav").css("opacity", "0");
            });
            $("#closeNoteUI").on("click", function() {
                $("#add-note-UI").removeClass("-top-[-0px]")
                $("#openSideNav").css("opacity", "1");
            });
        });

        $(document).ready(function() {
            $("#openNoteUI_card").on("click", function() {
                $("#add-note-UI").addClass("-top-[-0px]")
                $("#sideNavbackground").removeClass("-top-[-0px]")
                $("#sideNav").removeClass("-left-[-0px]");
                $("#openSideNav").css("opacity", "0")
            });
            $("#closeNoteUI").on("click", function() {
                $("#add-note-UI").removeClass("-top-[-0px]")
                $("#openSideNav").css("opacity", "1")
            });
        });
    </script>
</body>

</html>