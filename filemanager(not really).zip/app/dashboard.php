<?php

require_once "../php/userdata.php";

if (isset($_SESSION["loggedIN"])) {
    $loggedIN = $_SESSION["loggedIN"];
}

if ($loggedIN == false) {
    header("Location: /");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App | <?php echo TITLE; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <script src="https://kit.fontawesome.com/73d4b4352e.js" crossorigin="anonymous"></script>
</head>

<style>
    #sideNav {
        transition: all 0.5s;
        -webkit-transition: all 0.25s;
        z-index: 100;
    }

    .text-hr {
        margin-left: 15px !important;
        margin-top: 10px !important;
        margin-bottom: -6px !important;
    }

    .sidenav {
        transition: all 0.1s;
        -webkit-transition: all 0.1s;
    }

    .sidenav::after {
        margin-left: 300px;
    }

    .sidenav-button {
        transition: all 0.5s;
        -webkit-transition: all 0.25s;
    }

    .sidenav-button:hover {
        transform: translate(0px, 5px);
    }

    .sideNavbackground {
        z-index: 10;
        width: 200%;
        height: 100vh;
        background-color: #212121;
        position: fixed;
        opacity: 0.6;
        transition: all 0.25s;
        -webkit-transition: all 0.25;
    }
</style>

<body class="dark:bg-slate-800 font-[Poppins]">
    <span id="openSideNav" class="sidenav-button absolute text-white text-4xl top-5 left-4 cursor-pointer z-1">
        <i class="bi bi-list"></i>
    </span>
    <div id="sideNav" class=" fixed left-[-350px] sidenav z-50 fixed top-0 bottom-0 duration-2000
    p-2 w-[300px] overflow-y-auto text-center dark:bg-slate-700 h-screen">
        <div class="text-gray-100 text-xl">
            <div class="p-2.5 mt-1 flex items-center rounded-md" id="closeSideNav">
                <i class="bi bi-x ml-auto cursor-pointer"></i>
            </div>
            <div>
                <div class="text-hr">
                    <p class="text-slate-400 text-sm text-left right-10">
                        General
                    </p>
                </div>
                <a href="./dashboard">
                    <div class="button p-2.5 mt-2 bg-slate-600 flex items-center rounded-r-full px-4 rounded-r-full duration-200 cursor-pointer hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-house"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Home</span>
                    </div>
                </a>
                <a href="./notes">
                    <div class="button p-2.5 mt-2 flex items-center px-4 duration-200 cursor-pointer rounded-r-full hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-book"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Notes</span>
                    </div>
                </a>
                <div class="text-hr">
                    <p class="text-slate-400 text-sm text-left right-10">
                        Add
                    </p>
                </div>
                <div class="button p-2.5 mt-2 flex items-center px-4 duration-200 cursor-pointer rounded-r-full hover:rounded-r-full hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                    <i class="fa-solid fa-file"></i>
                    <span class="text-[15px] ml-4 text-gray-200">Add File</span>
                </div>
                <div class="button p-2.5 mt-2 flex items-center px-4 duration-200 cursor-pointer rounded-r-full hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                    <i class="fa-solid fa-folder"></i>
                    <span class="text-[15px] ml-4 text-gray-200">Add Folder</span>
                </div>
                <div class="text-hr">
                    <p class="text-slate-400 text-sm text-left right-10">
                        Manage Account
                    </p>
                </div>
                <a href="/settings">
                    <div class="button p-2.5 mt-2 flex items-center rounded-sm px-4 rounded-r-full duration-200 cursor-pointer hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-gear"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Settings</span>
                    </div>
                </a>
                <a href="php/logout">
                    <div class="button p-2.5 mt-2 flex items-center rounded-r-full px-4 rounded-r-full duration-200 cursor-pointer hover:rounded-r-full hover:bg-slate-600 transition ease-in">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span class="text-[15px] ml-4 text-gray-200">Logout</span>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="sideNavbackground top-[-9000px]" id="sideNavbackground"></div>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js"></script>
    <script>
        // function dropDown() {
        //     document.querySelector('#submenu').classList.toggle('hidden')
        //     document.querySelector('#arrow').classList.toggle('rotate-0')
        // }
        // dropDown()

        $(document).ready(function() {
            $("#openSideNav").on("click", function() {
                $("#sideNavbackground").addClass("-top-[-0px]")
                $("#openSideNav").css("display", "none");
                $("#sideNav").addClass("-left-[-0px]");
            });
            $("#closeSideNav").on("click", function() {
                $("#sideNavbackground").removeClass("-top-[-0px]")
                $("#sideNav").removeClass("-left-[-0px]");
                $("#openSideNav").css("display", "block");
            });
            $("#sideNavbackground").on("click", function() {
                $("#sideNavbackground").removeClass("-top-[-0px]")
                $("#sideNav").removeClass("-left-[-0px]")
                $("#openSideNav").css("display", "block");
            })
        });
    </script>
</body>

</html>