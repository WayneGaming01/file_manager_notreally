<?php

session_start();
unset($_SESSION["loggedIN"]);
unset($_SESSION["username"]);
header("Location: /");
