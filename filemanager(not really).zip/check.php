<?php

require_once __DIR__ . "/php/config.php";

function changeSpecialCharacters($x) {
    return strtolower(preg_replace("/[^a-z0-9-]+/i", "", $x));
}

if(!empty($_POST["username"])) {
    $sql = "SELECT * FROM test WHERE username='" . changeSpecialCharacters($_POST["username"]) . "'";
    $res = mysqli_query($conn, $sql);
    $c = mysqli_num_rows($res);
    if($c == 0) {
        echo "Username does not exists!";
    }
}