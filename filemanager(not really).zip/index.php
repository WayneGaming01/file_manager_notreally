<?php

// require_once __DIR__ . "/php/userdata.php";
require_once __DIR__ . "/php/config.php";
require_once __DIR__ . "/php/functions.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo TITLE; ?></title>
    <script src="//cdn.tailwindcss.com"></script>
    <link rel="icon" href="/icon.png">
</head>
<style>
    input[type="text"]:disabled,
    input[type="password"]:disabled {
        border-color: #475569;
        background-color: #374151;
    }

    input[type="text"]:disabled::placeholder,
    input[type="password"]:disabled::placeholder {
        color: #6b7280;
    }

    button[type="submit"]:disabled {
        color: #9ca3af;
        background-color: #374151;
        cursor: default;
    }
</style>

<body>
    <section class="bg-gray-50 h-screen dark:bg-gray-900">
        <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto h-screen lg:py-0">
            <div class="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
                    <div class="justify-center">
                        <h1 class="uppercase text-4xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                            Login
                        </h1>
                    </div>
                    <form class="space-y-4 md:space-y-6" action="" id="loginform" method="POST">
                        <div>
                            <label for="username" class="block mb-2 text-sm font-medium text-white dark:text-red-400" id="checkUsername"></label>
                            <input oninput="checkUser()" type="text" name="username" id="username" placeholder="Username" class="transition ease-in outline-0 bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        </div>
                        <div>
                            <label for="password" class="block mb-2 text-sm font-medium text-white dark:text-red-400" id="checkPassword"></label>
                            <input disabled type="password" name="password" id="password" placeholder="Password" class="transition ease-in outline-0 bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        </div>
                        <button disabled type="submit" id="login" name="login" class="cursor-pointer w-full text-white transition ease-in hover:dark:bg-gray-600 dark:bg-gray-700 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js"></script>
    <script>

        function checkUser() {
            var username = $("#username").val()

            jQuery.ajax({
                url: "check.php",
                data: "username=" + $("#username").val(),
                type: "POST",
                success: function(data) {
                    $("#checkUsername").html(data)

                    if ($("#username").val()) {
                        if (data == "Username does not exists!") {
                            $("#password").prop('disabled', true);
                            $("#login").prop('disabled', true);
                        } else {
                            $("#password").prop('disabled', false);
                            $("#login").prop('disabled', false);
                        }
                    } else {
                        $("#password").prop('disabled', true);
                        $("#login").prop('disabled', true);
                    }
                },
                error: function() {}
            })
        }


        $(document).ready(function() {
            $("#loginform").submit(function(e) {
                e.preventDefault()

                var username = $("#username").val()
                var password = $("#password").val()
                var submit = $("#login").val()

                if (username == "" || password == "") {
                    Swal.fire({
                        icon: "error",
                        title: "Input error",
                        text: "Input is empty!"
                    })
                }

                $.ajax({
                    url: "/php/userdata.php",
                    dataType: "text",
                    data: {
                        login: 1,
                        username: username,
                        password: password
                    },
                    type: "POST",
                    success: function(response) {
                        console.log(response)
                        if (response === "success") {
                            setTimeout(function() {
                                location.href = '/app/dashboard'
                            }, 3000)

                            $("#login").html("Logging In...");
                            $("#login").prop('disabled', true);
                            $("#username").prop('disabled', true);
                            $("#password").prop('disabled', true);
                        } else if(response === "Password is incorrect!") {
                            Swal.fire({
                                icon: "error",
                                title: "Account details",
                                text: `${response}`
                            })
                        }
                    },
                })
            })
        })
    </script>
</body>

</html>