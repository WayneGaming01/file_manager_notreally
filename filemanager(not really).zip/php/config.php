<?php

date_default_timezone_set('UTC');

mysqli_report(MYSQLI_REPORT_OFF ^ MYSQLI_REPORT_STRICT);

session_start();

define("TITLE", "FILE MANAGER");

//CHANGE DATABASE CREDENTIALS DEPENDS ON WHAT IS YOUR DB_SERVER DB_USER DB_PASS & DATABASE_NAME
//DB IS SHORT FOR --[DATABASE]--

define("DB_SERVER", ""); //Put your [DB_SERVER] ex. localhost
define("DB_USER", ""); //Put your [DB_USERNAME] ex. root
define("DB_PASSWORD", ""); //Put your [DB_PASSWORD] ex. abc
define("DB_NAME", ""); //Put your [DB_NAME] ex. phpmyadmin

$conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);

if(!$conn) {
    echo "Error connecting to " . DB_SERVER;
}