<?php

require_once __DIR__ . "/config.php";
require_once __DIR__ . "/functions.php";

$errors = array();

if (isset($_POST["login"])) {
    $username_Check =  mysqli_real_escape_string($conn, $_POST["username"]);
    $password_Check = mysqli_real_escape_string($conn, $_POST["password"]);

    $name_check = "SELECT * FROM test WHERE username='$username_Check'";
    $res = mysqli_query($conn, $name_check);
    if (mysqli_num_rows($res) > 0) {
        loginAccount($username_Check, $password_Check);
    }
}

if(isset($_POST["createnote"])){
    $note_text = mysqli_real_escape_string($conn, $_POST["note_text"]);

    createNote($note_text);
}

if(isset($_POST["deletenote"])){
    $note_id = mysqli_real_escape_string($conn, $_POST["note_id"]);

    deleteNote($note_id);
}