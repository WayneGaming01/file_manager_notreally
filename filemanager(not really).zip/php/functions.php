<?php

require_once __DIR__ . "/config.php";

function loginAccount($username, $password)
{
    $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);

    if (!$conn) {
        echo "Error connecting to " . DB_SERVER;
    }

    $username_SQL = $username;
    $password_SQL = $password;

    $name_check = "SELECT * FROM test WHERE username='$username_SQL'";
    $res = mysqli_query($conn, $name_check);
    if (mysqli_num_rows($res) > 0) {
        $fetch = mysqli_fetch_assoc($res);
        $fetch_pass = $fetch['password'];
        if (password_verify($password_SQL, $fetch_pass)) {
            $resf = mysqli_query($conn, "SELECT * FROM test WHERE username='$username_SQL'");
            if (mysqli_num_rows($resf) > 0) {
                $_SESSION["loggedIN"] = true;
                $_SESSION["username"] = $username_SQL;
                exit("success");
            } else {
                exit("fail");
            }
        } else {
            echo "Password is incorrect!";
        }
    }
}

function timeExchange($dTT, $full = false)
{
    $now = new DateTime;
    $ago = new DateTime($dTT);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $str = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );

    foreach ($str as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($str[$k]);
        }
    }

    if (!$full) $str = array_slice($str, 0, 1);
    return $str ? implode(', ', $str) . ' ago' : 'just now';
}

function createNote($notetext)
{
    $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);

    if (!$conn) {
        echo "Error connecting to " . DB_SERVER;
    }

    $notetext_SQL = $notetext;

    $sql = "INSERT INTO notes(text) VALUES ('$notetext_SQL')";
    $res = mysqli_query($conn, $sql);
    if ($res) {
        echo "Successfully created note.";
    }
}

function deleteNote($noteid) {
    $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);

    if (!$conn) {
        echo "Error connecting to " . DB_SERVER;
    }

    $noteid_SQL = $noteid;

    $sql = "DELETE FROM notes WHERE id='$noteid_SQL'";
    $res = mysqli_query($conn, $sql);
    if($res) {
        echo "Successfuly deleted the note.";
    }
}
